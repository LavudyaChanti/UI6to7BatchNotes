import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  
{
  myjsondata:object;
  constructor(private http: HttpClient) {}
  ngOnInit(): void {
   // Make the HTTP request:
   this.http.get('https://fakerestapi.azurewebsites.net/api/Users').subscribe(data => {
     console.log(data);
     this.myjsondata=data;
   });
 }
}
