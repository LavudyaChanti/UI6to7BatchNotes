import { Component } from '@angular/core';
@Component({
  selector: 'my-app',

  template:
   `<div> 
      Names:<ul>
                <li *ngFor='let i of names'>{{i}}</li>
            </ul>
    </div>
          `,
  
})
export class AppComponent 
{
  names:string[]=['Ram','Raj','Sai','Arun'];
}
