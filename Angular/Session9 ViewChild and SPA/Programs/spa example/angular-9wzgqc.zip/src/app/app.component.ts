import { Component } from '@angular/core';
@Component({
  selector: 'tg',

  templateUrl:'app.component.html',
  styleUrls:['app.component.css'],
  
})
export class AppComponent 
{
  
}
