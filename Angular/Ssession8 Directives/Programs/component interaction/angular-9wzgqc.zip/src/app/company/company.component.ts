import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit 
{

phone:string='9849098492';
  constructor() { }

  ngOnInit() {
  }

}