import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
 @Input() x:string;
  constructor() { }

  ngOnInit() {
  }

}