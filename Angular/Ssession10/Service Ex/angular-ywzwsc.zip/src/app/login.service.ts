import { Injectable } from '@angular/core';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class LoginService 
{
  users:User[]=[
    new User('tg','hyd'),
  ];
  constructor() { }
  loginCheck(x:string,y:string):boolean
  {

    for(var i=0;i<this.users.length;i++)
    {
      if(this.users[i].username==x && this.users[i].password==y)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
  }
}
