import { Component,Inject } from '@angular/core';
import { LoginService } from './login.service';
@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  
{
 username:string='';
  password:string='';
  msg:string='';
  constructor(@Inject(LoginService) private s:LoginService)
  {}
  doLogin(txt1)
  {
    if(this.s.loginCheck(this.username,this.password)==true)
    {
      this.msg='Login Success';
    }
    else
    {
      this.msg='Login Failed';
      txt1.focus();
    }
  }

}
