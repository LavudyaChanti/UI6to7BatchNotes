export class User
{
    username:string;
    password:string;
    constructor(a:string,b:string)
    {
        this.username=a;
        this.password=b;
    }
}
