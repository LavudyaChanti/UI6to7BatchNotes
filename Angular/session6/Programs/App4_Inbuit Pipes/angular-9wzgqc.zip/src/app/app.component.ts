import { Component } from '@angular/core';
@Component({
  selector: 'my-app',

  template:
   `<div> 
      <p>Today1:{{mydate}}</p>
      <p>date:{{mydate|date}}</p>
      <p>short:{{mydate|date:'shortDate'}}</p>
      <p>medium:{{mydate|date:'mediumDate'}}</p>
      <p>long:{{mydate|date:'longDate'}}</p>
        Short Time:{{mydate|date:'shortTime'}}      <hr>
        Long Time:{{mydate|date:'longTime'}}      <hr>
        Short:{{mydate|date:'short'}}      <hr>
        Medium:{{mydate|date:'medium'}}      <hr>
        d/M/y:{{mydate|date:'d/M/y'}}      <hr>
        d-M-y:{{mydate|date:'d-M-y'}}      <hr>
        h:m:s :{{mydate|date:'h:m:s'}}      <hr>
      <p>Name:{{name1}}</p>
      <p>Name:{{name1|uppercase}}</p>
      <p>Name:{{name1|lowercase}}</p>
      <p>Emp Data:{{emp|json}}</p>
      <p>Salary:{{salary|number:'.4'}}</p>
      <p>Salary:{{salary|currency:'USD'}}</p>
      <p>Salary:{{salary|currency:'EUR'}}</p>
      <p>ROI: {{roi|percent}}</p>
      <p>City:{{city}}</p>
      <p>City:{{city|slice:2:6}}</p>
      <p>City:{{city|slice:6:9}}</p>
      
    </div>
          `,
  
})
export class AppComponent 
{
  name1:string='James';
  emp:object={'eid':501,'ename':'Raj'};
  salary:number=45000.45123;
  roi:number=0.25;
  city:string='Hyderabad';
  mydate:Date=new Date();
}
